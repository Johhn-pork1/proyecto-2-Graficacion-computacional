package sistemasolar.transformaciones;

import sistemasolar.geometria.Vec2;
import sistemasolar.geometria.Vec3;

/**
 * UNIDAD 3 - TEMA 3.6 (YA RESUELTA): cámara sencilla para el modo 3D del proyecto.
 *
 * QUÉ HACE: 1) gira el mundo con una rotación sobre un eje FIJO (X) para que el plano de las órbitas se vea
 * inclinado; 2) proyecta cada punto 3D a 2D con perspectiva simple (lo cercano se ve más grande);
 * 3) mide la profundidad con un producto punto (tema 2.2) para dibujar primero lo lejano.
 */
public final class Camera {
    /** Dirección hacia el observador (en el sistema de la cámara). */
    private static final Vec3 HACIA_OBSERVADOR = new Vec3(0, 0, 1);

    private final Mat4 vista;   // rotación fija sobre X
    private final double d;     // distancia focal: controla cuánta perspectiva hay

    public Camera(double inclinacionRad, double focal) {
        this.vista = Mat4.rotationX(inclinacionRad);
        this.d = focal;
    }

    /** Profundidad: mayor valor = más cerca del observador (producto punto con HACIA_OBSERVADOR). */
    public double depth(Vec3 mundo) { return vista.apply(mundo).dot(HACIA_OBSERVADOR); }

    /** Factor de perspectiva: d / (d - z). Crece cuando el objeto está más cerca. */
    public double scaleAt(Vec3 mundo) { return d / (d - depth(mundo)); }

    /** Proyección 3D -> 2D (coordenadas del mundo 2D, con y hacia arriba). */
    public Vec2 project(Vec3 mundo) {
        Vec3 p = vista.apply(mundo);
        double f = d / (d - p.z);
        return new Vec2(p.x * f, p.y * f);
    }
}
