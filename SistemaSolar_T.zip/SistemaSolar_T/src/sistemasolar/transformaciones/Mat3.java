package sistemasolar.transformaciones;

import sistemasolar.geometria.Vec2;

/**
 * UNIDAD 3 - TEMAS 3.1 a 3.5: transformaciones 2D con COORDENADAS HOMOGÉNEAS
 * (matrices 3x3).
 *
 * 3.1 Lineales ......... rotation(), scale(), shearX() 3.2 Traslación .......
 * translation() 3.3 Homogéneas ....... apply(): el punto (x, y) se usa como (x,
 * y, 1) 3.4 Inversas ......... inverse() 3.5 Composición ...... times() y
 * rotationAbout()
 *
 * ¿POR QUÉ UNA MATRIZ 3x3 Y NO 2x2? Rotación, escala e inclinación son lineales
 * y caben en 2x2. La traslación SUMA una constante y eso no es lineal. Con una
 * coordenada extra w = 1 la traslación también se vuelve multiplicación de
 * matrices, y así TODAS las transformaciones se combinan multiplicando
 * matrices.
 *
 * FORMA DE LA MATRIZ (guardada por filas en el arreglo m, índices 0 a 8):
 *
 * | a b tx | m[0] m[1] m[2] a, b, c, d = parte lineal (rotar, escalar,
 * inclinar) M = | c d ty | = m[3] m[4] m[5] tx, ty = traslación | 0 0 1 | m[6]
 * m[7] m[8] la última fila siempre es 0 0 1 en 2D
 *
 * CONVENCIÓN: vectores columna, P' = M * P. En A.times(B) se aplica PRIMERO B y
 * luego A (se lee de derecha a izquierda, igual que en el pizarrón).
 */
public final class Mat3 {

    private final double[] m;

    private Mat3(double... m) {
        this.m = m;
    }

    /**
     * La matriz identidad: no cambia nada. Es el "1" de las matrices (M * I =
     * M).
     */
    public static Mat3 identity() {
        return new Mat3(1, 0, 0, 0, 1, 0, 0, 0, 1);
    }

    // =====================================================================================
    // EJEMPLO RESUELTO - TEMA 3.3 Coordenadas homogéneas (viene resuelto: léelo y úsalo como modelo)
    // =====================================================================================
    /**
     * Aplica la matriz a un punto. Se trata el punto como (x, y, 1):
     *
     * | a b tx | | x | x' = a*x + b*y + tx*1 | c d ty | * | y | = y' = c*x +
     * d*y + ty*1 | 0 0 1 | | 1 | w' = 1 (no hace falta calcularla)
     *
     * Con los índices del arreglo m: a=m[0], b=m[1], tx=m[2], c=m[3], d=m[4],
     * ty=m[5]. Fíjate cómo la traslación (tx, ty) se SUMA gracias a la
     * coordenada extra w = 1.
     */
    public Vec2 apply(Vec2 p) {
        return new Vec2(m[0] * p.x + m[1] * p.y + m[2], m[3] * p.x + m[4] * p.y + m[5]);
    }

    /**
     * AYUDA (viene resuelta). Construye una matriz directamente con sus seis
     * valores. Sirve para que el sistema solar se vea completo desde el inicio,
     * mientras escribes tus propias matrices. En TUS tareas de Mat3 no la uses:
     * escribe tú la matriz con new Mat3(...).
     */
    public static Mat3 desdeValores(double a, double b, double tx, double c, double d, double ty) {
        return new Mat3(a, b, tx, c, d, ty, 0, 0, 1);
    }

    // =====================================================================================
    // TAREA 2 - TEMAS 3.2 y 3.1: matrices de traslación, rotación, escala e inclinación
    // =====================================================================================
    /**
     * TEMA 3.2 Traslación T(tx, ty): mueve todos los puntos el mismo vector.
     *
     * | 1 0 tx | x' = x + tx | 0 1 ty | y' = y + ty | 0 0 1 |
     *
     * En el proyecto: coloca cada cuerpo en su posición y centra el origen en
     * la ventana.
     */
    public static Mat3 translation(double tx, double ty) {
        return new Mat3(
                1, 0, tx,
                0, 1, ty,
                0, 0, 1
        );
    }

    public static Mat3 rotation(double th) {
        double c = Math.cos(th);
        double s = Math.sin(th);
        return new Mat3(
                c, -s, 0,
                s, c, 0,
                0, 0, 1
        );
    }

    public static Mat3 scale(double sx, double sy) {
        return new Mat3(
                sx, 0, 0,
                0, sy, 0,
                0, 0, 1
        );
    }

    public static Mat3 shearX(double k) {
        return new Mat3(
                1, k, 0,
                0, 1, 0,
                0, 0, 1
        );
    }

    /**
     * TEMA 3.1 Rotación R(th) alrededor del ORIGEN, antihoraria, th en
     * RADIANES.
     *
     * | cos(th) -sen(th) 0 | x' = x*cos(th) - y*sen(th) | sen(th) cos(th) 0 |
     * y' = x*sen(th) + y*cos(th) | 0 0 1 |
     *
     * En el proyecto: giro propio de cada cuerpo y avance en la órbita. Ejemplo
     * a mano: th = 90° -> (x, y) pasa a (-y, x); A(1,1) -> (-1, 1).
     */
    /**
     * TEMA 3.1 Escala S(sx, sy): multiplica cada coordenada por un factor.
     *
     * | sx 0 0 | x' = sx*x | 0 sy 0 | y' = sy*y | 0 0 1 |
     *
     * En el proyecto: da el TAMAÑO a cada polígono (que nace con radio 1) y,
     * con un factor negativo en y, refleja el eje vertical al pasar de "mundo"
     * (y hacia arriba) a "pantalla" (y hacia abajo).
     */
    /**
     * TEMA 3.1 Inclinación (shear) en x con factor k: cada punto se corre en x
     * en proporción a su altura.
     *
     * | 1 k 0 | x' = x + k*y | 0 1 0 | y' = y | 0 0 1 |
     *
     * Convierte un cuadrado en paralelogramo. (Bono: úsala para que el Sol
     * "parpadee".)
     */
    // =====================================================================================
    // TAREA 3 - TEMA 3.5 Combinación de transformaciones
    // =====================================================================================
    /**
     * Producto de matrices: this * b. Se aplica PRIMERO b y luego this. EL
     * ORDEN IMPORTA: trasladar y luego escalar != escalar y luego trasladar
     * (ejemplo: A(1,1) -> (6,8) vs (4,5)).
     *
     * Cada elemento del resultado es fila de this por columna de b: r[i][j] =
     * suma sobre k de this[i][k] * b[k][j] En el arreglo por filas, el elemento
     * (i, j) vive en el índice 3*i + j.
     */
    public Mat3 times(Mat3 b) {
        double[] r = new double[9];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 3; k++) {
                    r[3 * i + j] += m[3 * i + k] * b.m[3 * k + j];
                }
            }
        }
        return new Mat3(r);
    }

    public static Mat3 rotationAbout(double th, Vec2 c) {
        return translation(c.x, c.y)
                .times(rotation(th))
                .times(translation(-c.x, -c.y));
    }

    // =====================================================================================
    // TAREA 4 - TEMA 3.4 Transformaciones inversas
    // =====================================================================================
    /**
     * Inversa de una transformación afín: la matriz que DESHACE a esta (M^-1 *
     * M = I).
     *
     * Si M = [A | t] (A es la parte 2x2 y t la traslación), entonces M^-1 =
     * [A^-1 | -A^-1 * t].
     *
     * det = a*d - b*c (si det = 0 no tiene inversa) A^-1 = 1/det * | d -b | |
     * -c a | traslación inversa: tx' = -(A^-1 fila 1 · (tx, ty)), ty' = -(A^-1
     * fila 2 · (tx, ty))
     *
     * En el proyecto: convierte el clic del mouse (pantalla) en coordenadas
     * LOCALES del polígono del planeta, para probar si cayó dentro (tema 2.5).
     */
    public Mat3 inverse() {
        double a = m[0], b = m[1], tx = m[2];
        double c = m[3], d = m[4], ty = m[5];

        double det = a * d - b * c;
        if (Math.abs(det) < 1e-12) {
            throw new ArithmeticException("La matriz no es invertible (determinante = 0)");
        }

        double ia = d / det;
        double ib = -b / det;
        double ic = -c / det;
        double id = a / det;

        double itx = -(ia * tx + ib * ty);
        double ity = -(ic * tx + id * ty);

        return new Mat3(
                ia, ib, itx,
                ic, id, ity,
                0, 0, 1
        );
    }
}
