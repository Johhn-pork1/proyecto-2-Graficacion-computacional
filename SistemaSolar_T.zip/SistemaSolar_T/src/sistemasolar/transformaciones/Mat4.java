package sistemasolar.transformaciones;

import sistemasolar.geometria.Vec3;

/**
 * UNIDAD 3 - TEMA 3.6 Transformaciones 3D con matrices homogéneas 4x4 (YA RESUELTA: se usa en el modo 3D).
 *
 * Igual que Mat3 pero con una dimensión más: el punto (x, y, z) se usa como (x, y, z, 1).
 *
 *  - rotationX/Y/Z ..... rotación sobre EJES FIJOS: la coordenada del eje de giro no cambia.
 *  - rotationAxis ...... rotación sobre un EJE ARBITRARIO (fórmula de Rodrigues en forma de matriz):
 *                          v' = v*cos(t) + (k × v)*sen(t) + k*(k·v)*(1 - cos(t))
 *  - rotationAxisThrough  si el eje NO pasa por el origen, se compone con traslaciones (tema 3.5).
 *
 * EN EL PROYECTO: el "plano de la órbita" de un cuerpo es una de estas rotaciones. Así Marte orbita en un
 * plano inclinado (eje fijo X) y la Luna en uno inclinado sobre un eje arbitrario.
 */
public final class Mat4 {
    private final double[] m; // 16 valores por filas

    private Mat4(double... m) { this.m = m; }

    public static Mat4 identity() {
        return new Mat4(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);
    }

    public static Mat4 translation(Vec3 t) {
        return new Mat4(1,0,0,t.x, 0,1,0,t.y, 0,0,1,t.z, 0,0,0,1);
    }

    /** Rx(t): gira alrededor del eje X.  y' = y*cos - z*sen,  z' = y*sen + z*cos,  x' = x. */
    public static Mat4 rotationX(double t) {
        double c = Math.cos(t), s = Math.sin(t);
        return new Mat4(1,0,0,0, 0,c,-s,0, 0,s,c,0, 0,0,0,1);
    }

    /** Ry(t): gira alrededor del eje Y.  x' = x*cos + z*sen,  z' = -x*sen + z*cos,  y' = y. */
    public static Mat4 rotationY(double t) {
        double c = Math.cos(t), s = Math.sin(t);
        return new Mat4(c,0,s,0, 0,1,0,0, -s,0,c,0, 0,0,0,1);
    }

    /** Rz(t): gira alrededor del eje Z. Es la rotación 2D de Mat3 con z sin cambio. */
    public static Mat4 rotationZ(double t) {
        double c = Math.cos(t), s = Math.sin(t);
        return new Mat4(c,-s,0,0, s,c,0,0, 0,0,1,0, 0,0,0,1);
    }

    /** Rotación de ángulo t alrededor de un eje arbitrario que pasa por el origen (fórmula de Rodrigues). */
    public static Mat4 rotationAxis(Vec3 axis, double t) {
        Vec3 k = axis.normalized();                       // el eje debe ser unitario
        double c = Math.cos(t), s = Math.sin(t), u = 1 - c;
        return new Mat4(
            c + k.x*k.x*u,       k.x*k.y*u - k.z*s,  k.x*k.z*u + k.y*s, 0,
            k.y*k.x*u + k.z*s,   c + k.y*k.y*u,      k.y*k.z*u - k.x*s, 0,
            k.z*k.x*u - k.y*s,   k.z*k.y*u + k.x*s,  c + k.z*k.z*u,     0,
            0, 0, 0, 1);
    }

    /** Eje arbitrario que pasa por el punto p: T(p) * R * T(-p) (misma idea que Mat3.rotationAbout). */
    public static Mat4 rotationAxisThrough(Vec3 p, Vec3 axis, double t) {
        return translation(p).times(rotationAxis(axis, t)).times(translation(p.mul(-1)));
    }

    /** Composición en 3D: this * b, se aplica primero b. */
    public Mat4 times(Mat4 b) {
        double[] r = new double[16];
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                for (int k = 0; k < 4; k++)
                    r[4*i + j] += m[4*i + k] * b.m[4*k + j];
        return new Mat4(r);
    }

    /** Aplica la matriz a un punto 3D, tratado como (x, y, z, 1). */
    public Vec3 apply(Vec3 p) {
        return new Vec3(
            m[0]*p.x + m[1]*p.y + m[2]*p.z  + m[3],
            m[4]*p.x + m[5]*p.y + m[6]*p.z  + m[7],
            m[8]*p.x + m[9]*p.y + m[10]*p.z + m[11]);
    }
}
