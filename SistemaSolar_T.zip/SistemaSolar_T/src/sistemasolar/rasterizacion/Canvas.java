package sistemasolar.rasterizacion;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.Arrays;

/**
 * UNIDAD 4 (ya resuelta) - TEMAS 4.1, 4.2 y 4.3: RASTERIZACIÓN con algoritmos propios.
 *
 * QUÉ ES: un "lienzo" de pixeles (un arreglo de enteros, uno por pixel) donde los algoritmos de esta clase
 * encienden pixeles uno por uno, SIN usar g.drawLine ni g.drawOval de Java2D. Así se ve cómo una computadora
 * convierte una figura matemática (una recta, un círculo) en pixeles.
 *
 *   4.1 linea() ........ algoritmo de BRESENHAM: recta usando solo sumas y restas de enteros
 *   4.2 lineaDoble() ... algoritmo de DOBLE PASO (Wu y Rokne): la misma recta decidiendo DOS pixeles por iteración
 *   4.3 circulo() ...... algoritmo del PUNTO MEDIO (Bresenham para círculos) con simetría de 8 octantes
 *
 * COORDENADAS: aquí se trabaja en PIXELES (enteros). El origen (0,0) es la esquina superior izquierda y la y crece
 * hacia ABAJO. Por eso la escena convierte antes del mundo a pantalla con el viewport (tema 3.5).
 *
 * EN EL PROYECTO: las órbitas circulares se trazan con circulo() (4.3), las órbitas inclinadas del modo 3D con
 * linea() entre puntos consecutivos (4.1) y la recta Sol-Tierra con lineaDoble() (4.2). Tecla R: compara con Java2D.
 */
public final class Canvas {
    private final int ancho, alto;
    private final int[] px;          // un entero por pixel: 0xRRGGBB
    private final BufferedImage img; // comparte el MISMO arreglo px: lo que cambiamos en px se ve en la imagen

    public Canvas(int ancho, int alto) {
        this.ancho = ancho;
        this.alto = alto;
        this.img = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
        this.px = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
    }

    public int ancho() { return ancho; }
    public int alto()  { return alto; }

    /** Pinta todo el lienzo de un color (0xRRGGBB). */
    public void limpiar(int rgb) { Arrays.fill(px, rgb); }

    /**
     * Enciende UN pixel. Si cae fuera del lienzo se descarta (así no se sale del arreglo).
     * OJO: esto es un recorte pixel por pixel, lento y poco elegante. En el tema 4.4 (Cohen-Sutherland)
     * se recorta la línea ANTES de trazarla.
     */
    public void pixel(int x, int y, int rgb) {
        if (x >= 0 && x < ancho && y >= 0 && y < alto) px[y * ancho + x] = rgb;
    }

    /** Lee el color de un pixel (para verificar resultados). Devuelve -1 si está fuera del lienzo. */
    public int leer(int x, int y) {
        return (x >= 0 && x < ancho && y >= 0 && y < alto) ? px[y * ancho + x] : -1;
    }

    /** Dibuja el lienzo completo en pantalla (esquina superior izquierda). */
    public void dibujarEn(Graphics2D g) { g.drawImage(img, 0, 0, null); }

    // =========================================================================================
    // TEMA 4.1 - RECTA DE BRESENHAM
    // =========================================================================================
    /**
     * Traza la recta de (x0,y0) a (x1,y1) usando SOLO enteros. Devuelve cuántas iteraciones hizo.
     *
     * IDEA (primer octante: la recta sube poco, 0 <= pendiente <= 1):
     *   Se avanza SIEMPRE un pixel en x. La pregunta en cada paso es: ¿y se queda igual o sube un pixel?
     *   La recta real vale y = y0 + (dy/dx)*x. Se compara qué pixel queda más cerca de ella. Para no usar
     *   decimales se multiplica todo por 2*dx y se lleva una "variable de decisión" d (un entero):
     *
     *       d inicial = 2*dy - dx
     *       si d > 0 : la recta pasó más cerca del pixel de arriba -> y sube y  d += 2*dy - 2*dx   (=B)
     *       si d <= 0: la recta sigue más cerca del pixel de abajo -> y igual    d += 2*dy         (=A)
     *
     * TODOS LOS OCTANTES: el mismo algoritmo sirve para cualquier recta con dos ajustes:
     *   - Si la recta es EMPINADA (sube más de lo que avanza), se intercambian los papeles de x y y:
     *     se avanza un pixel en y y se decide si x cambia.
     *   - Si va hacia la izquierda o hacia arriba, solo cambia el signo del avance (sx, sy).
     *
     * EJEMPLO A MANO: de (0,0) a (5,2): dx=5, dy=2, A=4, B=-6, d=-1
     *   (0,0) -> d=-1 (<=0) y igual, d=3 -> (1,0) -> d=3 (>0) y sube, d=-3 -> (2,1) -> d=1 -> (3,1)
     *   -> d=1 (>0) y sube, d=-5 -> (4,2) -> d=-1 -> (5,2).   Pixeles: (0,0)(1,0)(2,1)(3,1)(4,2)(5,2)
     */
    public int linea(int x0, int y0, int x1, int y1, int rgb) {
        int adx = Math.abs(x1 - x0), ady = Math.abs(y1 - y0);
        int sx = x1 >= x0 ? 1 : -1, sy = y1 >= y0 ? 1 : -1;       // hacia dónde avanza cada eje
        boolean empinada = ady > adx;                              // ¿sube más de lo que avanza?
        int mayor = empinada ? ady : adx;                          // eje que avanza siempre un pixel
        int menor = empinada ? adx : ady;                          // eje que a veces avanza

        int A = 2 * menor;                 // lo que se suma a d cuando el eje menor NO avanza
        int B = 2 * menor - 2 * mayor;     // lo que se suma a d cuando el eje menor SÍ avanza
        int d = 2 * menor - mayor;         // variable de decisión inicial
        int i = 0, j = 0, iteraciones = 0; // i: avance en el eje mayor, j: avance en el eje menor

        while (true) {
            ponerPixel(empinada, x0, y0, sx, sy, i, j, rgb);
            if (i == mayor) break;         // llegamos al final
            if (d > 0) { j++; d += B; }    // el eje menor avanza
            else       {      d += A; }    // el eje menor se queda
            i++;
            iteraciones++;
        }
        return iteraciones;
    }

    // =========================================================================================
    // TEMA 4.2 - LÍNEA DOBLE: ALGORITMO DE DOBLE PASO (Wu y Rokne)
    // =========================================================================================
    /**
     * Traza LA MISMA recta que linea(), pero en cada iteración decide DOS pixeles a la vez.
     * Devuelve cuántas iteraciones hizo (la mitad, aproximadamente, que linea()).
     *
     * IDEA: en dos pasos seguidos el eje menor puede avanzar 0, 1 o 2 pixeles, pero solo hay CUATRO
     * combinaciones posibles (paso 1, paso 2): (0,0), (0,1), (1,0) y (1,1). Mirando el valor de d se sabe cuál
     * de las cuatro ocurre, y se actualiza d una sola vez:
     *
     *      d <= 0  y  d <= -A        -> (0,0)   d += 2A
     *      d <= 0  y  d >  -A        -> (0,1)   d += A + B
     *      d >  0  y  d <= -B        -> (1,0)   d += B + A
     *      d >  0  y  d >  -B        -> (1,1)   d += 2B
     *
     *   (A y B son los mismos de linea(): A = 2*menor, B = 2*menor - 2*mayor).
     * Cada umbral sale de aplicar DOS veces la regla de Bresenham: después del primer paso d vale d+A o d+B,
     * y el segundo paso vuelve a preguntar si ese valor es mayor que 0.
     *
     * RESULTADO: pinta exactamente los mismos pixeles que linea(), con la mitad de las decisiones.
     * Si la recta tiene un número impar de pasos, el último se hace como en linea().
     */
    public int lineaDoble(int x0, int y0, int x1, int y1, int rgb) {
        int adx = Math.abs(x1 - x0), ady = Math.abs(y1 - y0);
        int sx = x1 >= x0 ? 1 : -1, sy = y1 >= y0 ? 1 : -1;
        boolean empinada = ady > adx;
        int mayor = empinada ? ady : adx;
        int menor = empinada ? adx : ady;

        int A = 2 * menor, B = 2 * menor - 2 * mayor, d = 2 * menor - mayor;
        int i = 0, j = 0, iteraciones = 0;

        ponerPixel(empinada, x0, y0, sx, sy, 0, 0, rgb);            // el primer pixel
        while (mayor - i >= 2) {                                    // quedan al menos dos pasos
            int paso1, paso2;                                       // cuánto avanza el eje menor en cada paso
            if (d <= 0) {
                if (d <= -A) { paso1 = 0; paso2 = 0; d += 2 * A; }
                else         { paso1 = 0; paso2 = 1; d += A + B; }
            } else {
                if (d <= -B) { paso1 = 1; paso2 = 0; d += B + A; }
                else         { paso1 = 1; paso2 = 1; d += 2 * B; }
            }
            ponerPixel(empinada, x0, y0, sx, sy, i + 1, j + paso1, rgb);
            ponerPixel(empinada, x0, y0, sx, sy, i + 2, j + paso1 + paso2, rgb);
            i += 2;
            j += paso1 + paso2;
            iteraciones++;
        }
        if (mayor - i == 1) {                                       // sobra un paso: se hace como Bresenham
            if (d > 0) j++;
            i++;
            ponerPixel(empinada, x0, y0, sx, sy, i, j, rgb);
            iteraciones++;
        }
        return iteraciones;
    }

    /**
     * Convierte (i, j) -- avance en el eje mayor y en el eje menor -- al pixel real (x, y).
     * Si la recta es empinada, el eje mayor es y (y no x), así que se intercambian.
     */
    private void ponerPixel(boolean empinada, int x0, int y0, int sx, int sy, int i, int j, int rgb) {
        if (!empinada) pixel(x0 + i * sx, y0 + j * sy, rgb);
        else           pixel(x0 + j * sx, y0 + i * sy, rgb);
    }

    // =========================================================================================
    // TEMA 4.3 - CÍRCULO: ALGORITMO DEL PUNTO MEDIO
    // =========================================================================================
    /**
     * Traza la circunferencia de centro (cx,cy) y radio r (en pixeles) usando solo enteros.
     *
     * SIMETRÍA DE 8 OCTANTES: un círculo es igual en sus ocho octantes. Basta calcular el arco que va desde la
     * parte de arriba (0, r) hasta la diagonal (r/√2, r/√2) y reflejar cada punto (x, y) en ocho lugares:
     * (±x, ±y) y (±y, ±x). Eso reduce el trabajo a una octava parte.
     *
     * DECISIÓN EN CADA PASO: se avanza un pixel en x y se pregunta si y baja un pixel o se queda. Se evalúa la
     * ecuación del círculo f(x, y) = x² + y² - r² en el PUNTO MEDIO entre los dos pixeles candidatos:
     *     f < 0  el punto medio está dentro del círculo -> el círculo pasa más cerca del pixel de ARRIBA (y igual)
     *     f >= 0 el punto medio está fuera              -> el círculo pasa más cerca del pixel de ABAJO (y baja)
     * Con álgebra, f en el punto medio se actualiza solo con sumas de enteros:
     *     d inicial = 1 - r
     *     d < 0 : d += 2x + 1                  (y igual)
     *     d >= 0: y--  y  d += 2(x - y) + 1    (y baja)
     *
     * EJEMPLO A MANO: r = 5 da (0,5)(1,5)(2,5)(3,4)(4,3)... y sus reflejos: 28 pixeles en total.
     * Ningún pixel queda a más de 0.5 del radio exacto.
     */
    public void circulo(int cx, int cy, int r, int rgb) {
        if (r < 0) return;
        int x = 0, y = r, d = 1 - r;
        puntos8(cx, cy, x, y, rgb);
        while (x < y) {
            x++;
            if (d < 0) {
                d += 2 * x + 1;            // y se queda
            } else {
                y--;                        // y baja un pixel
                d += 2 * (x - y) + 1;
            }
            puntos8(cx, cy, x, y, rgb);
        }
    }

    /** Refleja un punto (x, y) del primer octante en los ocho octantes del círculo. */
    private void puntos8(int cx, int cy, int x, int y, int rgb) {
        pixel(cx + x, cy + y, rgb); pixel(cx - x, cy + y, rgb);
        pixel(cx + x, cy - y, rgb); pixel(cx - x, cy - y, rgb);
        pixel(cx + y, cy + x, rgb); pixel(cx - y, cy + x, rgb);
        pixel(cx + y, cy - x, rgb); pixel(cx - y, cy - x, rgb);
    }
}
