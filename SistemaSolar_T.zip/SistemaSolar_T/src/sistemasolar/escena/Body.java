package sistemasolar.escena;
import sistemasolar.geometria.Polygon;
import sistemasolar.geometria.Triangulator;
import sistemasolar.geometria.Vec2;
import sistemasolar.geometria.Vec3;
import sistemasolar.transformaciones.Camera;
import sistemasolar.transformaciones.Mat3;
import sistemasolar.transformaciones.Mat4;

import java.awt.Color;
import java.util.List;

/**
 * Cuerpo celeste (Sol, planeta, luna o asteroide).
 *
 *   UNIDAD 2:  la forma es un POLÍGONO (2.4) que se TRIANGULA una sola vez (2.7) para rellenarlo.
 *   UNIDAD 3:  cada cuadro se calcula la MATRIZ MODELO  M = T(posición) * R(giro propio) * S(tamaño)
 *              (3.1 a 3.5), y la posición sale de componer matrices a lo largo de la JERARQUÍA
 *              Sol -> Tierra -> Luna: la Luna orbita alrededor de donde esté la Tierra en ese momento.
 *
 * Cada cuerpo tiene un "padre" (alrededor de quién orbita). El Sol no tiene padre.
 */
public class Body {
    public final String nombre;
    public final Polygon forma;            // 2.4: forma LOCAL (centrada en el origen, radio ~1)
    public final List<int[]> triangulos;   // 2.7: triángulos para rellenar
    public final Color color;
    public final Body padre;               // alrededor de quién orbita (null = el Sol)

    private final double radioOrbita;      // distancia al padre
    private final double velOrbital;       // rad/s alrededor del padre
    private final double fase;             // ángulo inicial en la órbita
    private final double velGiro;          // rad/s de giro sobre sí mismo
    private final double tamano;           // factor de escala del polígono
    private final Mat4 planoOrbita;        // 3.6 (solo modo 3D): rotación que inclina el plano de la órbita

    // ---- Estado que se recalcula en cada cuadro ----
    public Vec2 pos = new Vec2(0, 0);      // posición en el mundo 2D (y hacia arriba)
    public Vec3 pos3 = new Vec3(0, 0, 0);  // posición 3D (solo modo 3D)
    public double profundidad = 0;         // para dibujar primero lo lejano (solo modo 3D)
    public Mat3 modelo = Mat3.identity();  // matriz modelo: coordenadas locales -> mundo
    public Vec2 velocidad = new Vec2(1, 0);// dirección unitaria del último movimiento (flecha verde)

    public Body(String nombre, Polygon forma, Color color, Body padre, double radioOrbita,
                double velOrbital, double fase, double velGiro, double tamano, Mat4 planoOrbita) {
        this.nombre = nombre;
        this.forma = forma.asCCW();                          // la triangulación necesita sentido antihorario
        this.triangulos = Triangulator.earClipping(this.forma);
        this.color = color;
        this.padre = padre;
        this.radioOrbita = radioOrbita; this.velOrbital = velOrbital; this.fase = fase;
        this.velGiro = velGiro; this.tamano = tamano; this.planoOrbita = planoOrbita;
    }

    public boolean tieneOrbita() { return radioOrbita > 0; }
    public double tamano()       { return tamano; }
    public double radioOrbita()  { return radioOrbita; }

    /**
     * Recalcula la posición y la matriz modelo en el instante t (segundos).
     * IMPORTANTE: el padre debe actualizarse ANTES que el hijo (la lista de cuerpos va en ese orden).
     */
    public void update(double t, boolean modo3D, Camera cam) {
        Vec2 posAnterior = pos;
        double ang = fase + velOrbital * t;       // ángulo actual en la órbita
        double escala = tamano;

        if (!modo3D) {
            // TAREA 5a - TEMAS 3.2, 3.1 y 3.5: POSICIÓN en la órbita (modo 2D)
            Vec2 posPadre = (padre == null) ? new Vec2(0, 0) : padre.pos;
            Mat3 transformacionOrbita = Mat3.translation(posPadre.x, posPadre.y)
                                            .times(Mat3.rotation(ang))
                                            .times(Mat3.translation(radioOrbita, 0));
            pos = transformacionOrbita.apply(new Vec2(0, 0));
            profundidad = 0;
        } else {
            Vec3 padre3 = (padre == null) ? new Vec3(0, 0, 0) : padre.pos3;
            pos3 = padre3.add(puntoOrbita3D(ang));
            pos = cam.project(pos3);
            profundidad = cam.depth(pos3);
            escala = tamano * cam.scaleAt(pos3);
        }

        // TAREA 5b - TEMA 3.5 Composición: MATRIZ MODELO del polígono
        // modelo = T(pos) * R(velGiro * t) * S(escala, escala)
        modelo = Mat3.translation(pos.x, pos.y)
                     .times(Mat3.rotation(velGiro * t))
                     .times(Mat3.scale(escala, escala));

        // Dirección de movimiento = resta de posiciones (tema 2.1), normalizada.
        Vec2 d = pos.sub(posAnterior);
        if (d.length() > 1e-9) velocidad = d.normalized();
    }

    private Vec3 puntoOrbita3D(double ang) {
        Vec3 local = new Vec3(radioOrbita * Math.cos(ang), 0, radioOrbita * Math.sin(ang));
        return planoOrbita == null ? local : planoOrbita.apply(local);
    }

    public Vec2[] puntosOrbita(int n, boolean modo3D, Camera cam) {
        Vec2[] r = new Vec2[n];
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            if (!modo3D) {
                Vec2 c = (padre == null) ? new Vec2(0, 0) : padre.pos;
                r[i] = new Vec2(c.x + radioOrbita * Math.cos(a), c.y + radioOrbita * Math.sin(a));
            } else {
                Vec3 c3 = (padre == null) ? new Vec3(0, 0, 0) : padre.pos3;
                r[i] = cam.project(c3.add(puntoOrbita3D(a)));
            }
        }
        return r;
    }
}