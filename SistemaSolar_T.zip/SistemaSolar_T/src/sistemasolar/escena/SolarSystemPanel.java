package sistemasolar.escena;

import sistemasolar.geometria.Geometry;
import sistemasolar.geometria.Polygon;
import sistemasolar.geometria.Vec2;
import sistemasolar.geometria.Vec3;
import sistemasolar.rasterizacion.Canvas;
import sistemasolar.transformaciones.Camera;
import sistemasolar.transformaciones.Mat3;
import sistemasolar.transformaciones.Mat4;

import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Panel que dibuja el sistema solar y recibe el teclado y el mouse.
 *
 * Teclas:  ESPACIO = pausa   T = malla de triángulos   3 = modo 3D   + / - = zoom   R = raster propio / Java2D   clic = seleccionar
 *
 * 
 */
public class SolarSystemPanel extends JPanel {
    private final Camera cam = new Camera(Math.toRadians(25), 900);   // cámara del modo 3D
    private final List<Body> cuerpos = new ArrayList<>();
    private final Body sol, tierra, luna, marte, asteroide;

    private double t = 0;
    private boolean pausa = false, verMalla = false, modo3D = false;
    private boolean rasterPropio = true;             // true: órbitas con los algoritmos de la Unidad 4; false: Java2D
    private Canvas canvas = new Canvas(960, 640);   //  lienzo de pixeles propio
    private double zoom = 1.0;
    private Vec2 mouse = new Vec2(-1e6, -1e6);
    private Body bajoMouse, seleccionado;
    private Vec2 tierraInicial;                      // para avisar si la Tierra no se mueve (Tarea 5a)
    private Mat3 viewport = Mat3.identity();

    public SolarSystemPanel() {
        setPreferredSize(new Dimension(960, 640));
        setBackground(new Color(8, 10, 24));
        setFocusable(true);

        // [2.4] Cada cuerpo es un polígono. El Sol es una estrella (CÓNCAVA), la Tierra un octágono (convexo),
        //       la Luna un hexágono, Marte una estrella de 5 puntas y el asteroide un polígono irregular.
        // Parámetros: nombre, forma, color, padre, radioOrbita, velOrbital, fase, velGiro, tamaño, planoOrbita(3D)
        sol       = new Body("Sol", Polygon.star(8, 1, 0.62), new Color(255, 196, 60),
                             null, 0, 0, 0, 0.4, 55, null);
        tierra    = new Body("Tierra", Polygon.regular(8, 1), new Color(80, 150, 230),
                             sol, 150, 0.8, 0, 1.5, 20, null);
        luna      = new Body("Luna", Polygon.regular(6, 1), new Color(200, 200, 205),
                             tierra, 48, 3.2, 1.0, 1.0, 7,
                             Mat4.rotationAxis(new Vec3(1, 0, 1), Math.toRadians(25)));  // [3.6] eje ARBITRARIO
        marte     = new Body("Marte", Polygon.star(5, 1, 0.5), new Color(225, 105, 75),
                             sol, 270, 0.45, 2.0, -1.0, 15,
                             Mat4.rotationX(Math.toRadians(14)));                        // [3.6] eje FIJO X
        asteroide = new Body("Asteroide", Polygon.irregular(9, 0.45, 1.0, 7), new Color(160, 140, 120),
                             sol, 210, 0.6, 4.0, 2.0, 9, null);

        // El PADRE siempre antes que el HIJO (la Luna se actualiza después de la Tierra).
        cuerpos.add(sol); cuerpos.add(tierra); cuerpos.add(luna); cuerpos.add(marte); cuerpos.add(asteroide);
        avanzar(0);
        tierraInicial = tierra.pos;

        new Timer(16, e -> { if (!pausa) avanzar(t + 0.016); repaint(); }).start();   // ~60 cuadros por segundo

        addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) pausa = !pausa;
                char c = e.getKeyChar();
                if (c == 't' || c == 'T') verMalla = !verMalla;
                if (c == '3') modo3D = !modo3D;
                if (c == 'r' || c == 'R') rasterPropio = !rasterPropio;
                if (c == '+') zoom = Math.min(3.0, zoom * 1.1);
                if (c == '-') zoom = Math.max(0.4, zoom / 1.1);
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseMoved(MouseEvent e) { mouse = new Vec2(e.getX(), e.getY()); }
        });
        addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                requestFocusInWindow();
                mouse = new Vec2(e.getX(), e.getY());
                seleccionado = cuerpoEn(mouse);
            }
        });
    }

    /** Avanza la simulación al instante nuevoT y recalcula la posición y la matriz de cada cuerpo. */
    public void avanzar(double nuevoT) {
        t = nuevoT;
        for (Body b : cuerpos) b.update(t, modo3D, cam);
    }

    public void setVerMalla(boolean v) { verMalla = v; }
    public void setModo3D(boolean v)   { modo3D = v; }
    public void setRasterPropio(boolean v) { rasterPropio = v; }

    // -----------------------------------------------------------------------------------------
    // [2.5 + 3.4] SELECCIÓN CON EL MOUSE
    //   Problema: el mouse está en coordenadas de PANTALLA, pero cada polígono vive en coordenadas LOCALES.
    //   Solución: la matriz completa  viewport * modelo  lleva local -> pantalla. Su INVERSA (3.4) hace el
    //   camino contrario: pantalla -> local. Ya en el sistema local, se prueba punto-en-polígono (2.5),
    //   que funciona incluso en las estrellas (cóncavas).
    // -----------------------------------------------------------------------------------------
    private Body cuerpoEn(Vec2 pantalla) {
        List<Body> orden = ordenDeDibujo();
        for (int i = orden.size() - 1; i >= 0; i--) {              // el último dibujado está arriba
            Body b = orden.get(i);
            try {
                Mat3 pantallaALocal = viewport.times(b.modelo).inverse();
                Vec2 local = pantallaALocal.apply(pantalla);
                if (Geometry.pointInPolygon(local, b.forma.vertices())) return b;   // [2.5]
            } catch (ArithmeticException ignorada) {
                // matriz no invertible (por ejemplo, escala 0): se ignora este cuerpo
            }
        }
        return null;
    }

    /** Lejano primero, cercano después (en 2D todos tienen profundidad 0 y se respeta el orden de la lista). */
    private List<Body> ordenDeDibujo() {
        List<Body> orden = new ArrayList<>(cuerpos);
        orden.sort(Comparator.comparingDouble((Body b) -> b.profundidad));
        return orden;
    }

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        dibujar((Graphics2D) g.create(), getWidth(), getHeight());
    }

    // TAREA 5c: Viewport dentro de dibujar(Graphics2D g, int w, int h)
    public void dibujar(Graphics2D g, int w, int h) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(new Color(8, 10, 24));
        g.fillRect(0, 0, w, h);

        // Tarea 5c (temas 1.3, 3.2 y 3.5): viewport = T(w/2, h/2) * S(zoom, -zoom)
        viewport = Mat3.translation(w / 2.0, h / 2.0)
                       .times(Mat3.scale(zoom, -zoom));
        bajoMouse = cuerpoEn(mouse);

        if (rasterPropio) dibujarRasterPropio(g, w, h);   // [4.1, 4.2, 4.3]
        else dibujarOrbitas(g);                            // Java2D, para comparar (tecla R)
        for (Body b : ordenDeDibujo()) dibujarCuerpo(g, b);
        for (Body b : cuerpos) if (b != sol && b != asteroide) dibujarFlechaVelocidad(g, b);
        dibujarHud(g, h);
    }
    // -----------------------------------------------------------------------------------------
    // [4.1 + 4.2 + 4.3] FONDO, ÓRBITAS Y RECTA SOL-TIERRA CON ALGORITMOS PROPIOS (clase faltante)
    //   - Órbita circular (modo 2D) ........ circulo() del punto medio [4.3]
    //   - Órbita inclinada (modo 3D) ....... linea() de Bresenham entre puntos consecutivos [4.1]
    //   - Recta Sol-Tierra ................. lineaDoble() de doble paso [4.2]
    // El faltante trabaja en PIXELES enteros, así que antes se pasa cada punto del mundo a la pantalla con el
    // viewport (tema 3.3). Después el Canvas se dibuja de fondo y encima se dibujan los cuerpos.
    // -----------------------------------------------------------------------------------------
    private void dibujarRasterPropio(Graphics2D g, int w, int h) {
        if (canvas.ancho() != w || canvas.alto() != h) canvas = new Canvas(w, h);   // la ventana cambió de tamaño
        canvas.limpiar(0x080A18);
        int colorOrbita = 0x333541;

        for (Body b : cuerpos) {
            if (!b.tieneOrbita()) continue;
            if (!modo3D) {
                // El centro de la órbita es la posición del padre; el radio en pixeles sale de pasar el
                // radio del mundo por el mismo viewport (así el zoom afecta igual al círculo y a los cuerpos).
                Vec2 centro = viewport.apply((b.padre == null) ? new Vec2(0, 0) : b.padre.pos);
                double rPx = Math.abs(viewport.apply(new Vec2(b.radioOrbita(), 0)).x - viewport.apply(new Vec2(0, 0)).x);
                canvas.circulo((int) Math.round(centro.x), (int) Math.round(centro.y), (int) Math.round(rPx), colorOrbita);
            } else {
                Vec2[] pts = b.puntosOrbita(120, true, cam);
                Vec2 previo = viewport.apply(pts[pts.length - 1]);
                for (Vec2 pt : pts) {
                    Vec2 actual = viewport.apply(pt);
                    canvas.linea((int) Math.round(previo.x), (int) Math.round(previo.y),
                                 (int) Math.round(actual.x), (int) Math.round(actual.y), colorOrbita);
                    previo = actual;
                }
            }
        }
        Vec2 ps = viewport.apply(sol.pos), pt = viewport.apply(tierra.pos);
        canvas.lineaDoble((int) Math.round(ps.x), (int) Math.round(ps.y),
                          (int) Math.round(pt.x), (int) Math.round(pt.y), 0x6F5BA8);
        canvas.dibujarEn(g);
    }

    private void dibujarOrbitas(Graphics2D g) {
        g.setStroke(new BasicStroke(1f));
        g.setColor(new Color(255, 255, 255, 45));
        for (Body b : cuerpos) {
            if (!b.tieneOrbita()) continue;
            Vec2[] pts = b.puntosOrbita(120, modo3D, cam);
            int[] xs = new int[pts.length], ys = new int[pts.length];
            for (int i = 0; i < pts.length; i++) {
                Vec2 p = viewport.apply(pts[i]);                   // [3.3] mundo -> pantalla con la matriz viewport
                xs[i] = (int) Math.round(p.x); ys[i] = (int) Math.round(p.y);
            }
            g.drawPolygon(xs, ys, pts.length);
        }
    }

    private void dibujarCuerpo(Graphics2D g, Body b) {
        // [2.4 + 3.3] Cada vértice LOCAL pasa primero por la matriz modelo (local -> mundo) y después por el
        // viewport (mundo -> pixeles). Es lo mismo que usar una sola matriz compuesta viewport * modelo [3.5],
        // pero aplicada en dos pasos. (Bono: reemplázalo por una sola transformación con viewport.times(b.modelo)
        // y comprueba que se ve idéntico.)
        List<Vec2> p = b.forma.transform(b.modelo).transform(viewport).vertices();

        // [2.7] Se rellena TRIÁNGULO por triángulo (cada uno con un tono distinto para que se note la malla).
        int k = 0;
        for (int[] tri : b.triangulos) {
            float f = 0.78f + 0.22f * ((k++ % 3) / 2f);
            g.setColor(new Color(Math.min(255, (int) (b.color.getRed() * f)),
                                 Math.min(255, (int) (b.color.getGreen() * f)),
                                 Math.min(255, (int) (b.color.getBlue() * f))));
            g.fillPolygon(xs(p, tri), ys(p, tri), 3);
        }
        if (verMalla) {                                              // tecla T: ver cómo se triangularon
            g.setStroke(new BasicStroke(1f));
            g.setColor(new Color(255, 255, 255, 170));
            for (int[] tri : b.triangulos) g.drawPolygon(xs(p, tri), ys(p, tri), 3);
        }
        // Contorno: más grueso si el mouse está encima [2.5] o si está seleccionado.
        g.setStroke(new BasicStroke(b == seleccionado ? 3.2f : (b == bajoMouse ? 2.4f : 1.2f)));
        g.setColor(b == seleccionado ? new Color(255, 230, 120) : new Color(255, 255, 255, 190));
        int n = p.size();
        int[] px = new int[n], py = new int[n];
        for (int i = 0; i < n; i++) { px[i] = (int) Math.round(p.get(i).x); py[i] = (int) Math.round(p.get(i).y); }
        g.drawPolygon(px, py, n);

        Vec2 c = viewport.apply(b.pos);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.setColor(new Color(220, 225, 240));
        g.drawString(b.nombre, (int) c.x - 20, (int) (c.y + b.tamano() * zoom * 1.3 + 14));
    }

    private static int[] xs(List<Vec2> p, int[] t) {
        return new int[]{(int) Math.round(p.get(t[0]).x), (int) Math.round(p.get(t[1]).x), (int) Math.round(p.get(t[2]).x)};
    }
    private static int[] ys(List<Vec2> p, int[] t) {
        return new int[]{(int) Math.round(p.get(t[0]).y), (int) Math.round(p.get(t[1]).y), (int) Math.round(p.get(t[2]).y)};
    }

    // [2.1 + 2.2] FLECHA DE VELOCIDAD. La dirección del movimiento es una resta de posiciones (ya calculada
    // en Body.update). Se convierte a pantalla con el viewport y las dos puntas de la flecha se dibujan con
    // la PERPENDICULAR del vector (perp).
    private void dibujarFlechaVelocidad(Graphics2D g, Body b) {
        Vec2 p0 = viewport.apply(b.pos);
        Vec2 p1 = viewport.apply(b.pos.add(b.velocidad));
        Vec2 dir = p1.sub(p0).normalized();                          // dirección en pixeles
        Vec2 inicio = p0.add(dir.mul(b.tamano() * zoom * 1.2));
        Vec2 punta = inicio.add(dir.mul(40));
        Vec2 base = punta.sub(dir.mul(9));
        Vec2 izq = base.add(dir.perp().mul(4.5)), der = base.sub(dir.perp().mul(4.5));
        g.setStroke(new BasicStroke(1.8f));
        g.setColor(new Color(120, 230, 170));
        g.drawLine((int) inicio.x, (int) inicio.y, (int) punta.x, (int) punta.y);
        g.fillPolygon(new int[]{(int) punta.x, (int) izq.x, (int) der.x},
                      new int[]{(int) punta.y, (int) izq.y, (int) der.y}, 3);
    }

    private void dibujarHud(Graphics2D g, int h) {
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        g.setColor(new Color(215, 220, 235));
        int y = 22;
        g.drawString(String.format("%-10s %8s %8s %6s", "Cuerpo", "Area", "Convexo", "Tri."), 16, y);   // [2.4] [2.7]
        for (Body b : cuerpos) {
            y += 18;
            g.drawString(String.format("%-10s %8.2f %8s %6d", b.nombre, b.forma.area(),
                    b.forma.isConvex() ? "si" : "no", b.triangulos.size()), 16, y);
        }
        // [2.3] ORIENTACIÓN de 3 puntos: ¿de qué lado de la recta Sol->Tierra está la Luna? (fase lunar)
        // [2.6] DISTANCIA punto-recta: cerca de 0 la Luna está alineada con el Sol y la Tierra (eclipse).
        Vec2 s = sol.pos, te = tierra.pos, lu = luna.pos;
        int o = Geometry.orientation(s, te, lu);
        double d = Geometry.signedDistanceToLine(lu, s, te);
        y += 26;
        g.drawString(String.format("Luna respecto a la recta Sol->Tierra: %s, a %.1f u",
                o > 0 ? "IZQUIERDA" : (o < 0 ? "DERECHA" : "SOBRE la recta"), Math.abs(d)), 16, y);
        y += 18;
        g.drawString("Orbitas: " + (rasterPropio ? "algoritmos propios (4.1-4.3)" : "Java2D") + "   Modo: " + (modo3D ? "3D" : "2D") + "   Zoom: " + String.format("%.2f", zoom)
                + "   Bajo el mouse: " + (bajoMouse == null ? "-" : bajoMouse.nombre)
                + "   Seleccionado: " + (seleccionado == null ? "-" : seleccionado.nombre), 16, y);
        // AVISO DE PENDIENTES: revisa el resultado de TU código y dice qué tarea falta.
        g.setColor(new Color(255, 214, 102));
        if (!modo3D) {
            boolean ejeYalReves = viewport.apply(new Vec2(0, 1)).y > viewport.apply(new Vec2(0, 0)).y;
            boolean zoomMal = Math.abs(viewport.apply(new Vec2(1, 0)).x - viewport.apply(new Vec2(0, 0)).x - zoom) > 1e-6;
            boolean noOrbita = t > 0.5 && tierra.pos.sub(tierraInicial).length() < 1e-6;
            y += 26;
            if (noOrbita)              { g.drawString("PENDIENTE Tarea 5a: los cuerpos no orbitan (Body.update, posición)", 16, y); y += 18; }
            if (ejeYalReves || zoomMal){ g.drawString("PENDIENTE Tarea 5c: el eje y está al revés o el zoom no funciona (viewport)", 16, y); y += 18; }
        }
        g.setColor(new Color(150, 158, 185));
        g.drawString("[ESPACIO] pausa  [T] malla  [3] modo 3D  [+/-] zoom  [R] raster  [clic] seleccionar", 16, h - 14);
    }
}
