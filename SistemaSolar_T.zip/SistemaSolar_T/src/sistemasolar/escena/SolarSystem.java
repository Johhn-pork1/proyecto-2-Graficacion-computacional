package sistemasolar.escena;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class SolarSystem {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Sistema solar - Graficación computacional");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            SolarSystemPanel panel = new SolarSystemPanel();
            f.add(panel);
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
            panel.requestFocusInWindow();
        });
    }
}
