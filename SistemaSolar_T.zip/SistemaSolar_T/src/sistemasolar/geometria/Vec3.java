package sistemasolar.geometria;

/**
 * UNIDAD 2 - TEMAS 2.1 y 2.2 en 3D.
 * Se usa en el modo 3D del proyecto (tema 3.6): posiciones 3D y profundidad de la cámara.
 */
public final class Vec3 {
    public final double x, y, z;

    public Vec3(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }

    public Vec3 add(Vec3 o)   { return new Vec3(x + o.x, y + o.y, z + o.z); }
    public Vec3 sub(Vec3 o)   { return new Vec3(x - o.x, y - o.y, z - o.z); }
    public Vec3 mul(double k) { return new Vec3(x * k, y * k, z * k); }
    public double length()    { return Math.sqrt(x * x + y * y + z * z); }
    public Vec3 normalized()  { double l = length(); return l == 0 ? this : mul(1.0 / l); }

    /** Producto punto: proyección de un vector sobre otro (la cámara lo usa para medir profundidad). */
    public double dot(Vec3 o) { return x * o.x + y * o.y + z * o.z; }

    /** Producto cruz: vector perpendicular a ambos (regla de la mano derecha). */
    public Vec3 cross(Vec3 o) {
        return new Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x);
    }
}
