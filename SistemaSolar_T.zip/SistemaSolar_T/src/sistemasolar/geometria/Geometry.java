package sistemasolar.geometria;

import java.util.List;

/**
 * UNIDAD 2 - TEMAS 2.3, 2.5 y 2.6. Todo se apoya en el producto cruz 2D 
 *
 * PARA QUÉ SE USA EN EL PROYECTO:
 *   - orientation: decide si un vértice es "convexo" (triangulación) y de qué lado está la Luna
 *                  respecto a la recta Sol-Tierra (fase lunar).
 *   - pointInPolygon: saber si el mouse está dentro de un planeta (selección).
 *   - signedDistanceToLine: distancia de la Luna a la recta Sol-Tierra (cerca de 0 = eclipse).
 */
public final class Geometry {
    private static final double EPS = 1e-9;

    private Geometry() {}

    // TEMA 2.3 Orientación de 3 puntos
    /** (b-a) x (c-a): >0 giro a la izquierda (antihorario), <0 a la derecha, 0 colineales. */
    public static double orient(Vec2 a, Vec2 b, Vec2 c) {
        return b.sub(a).cross(c.sub(a));
    }

    /** +1 antihorario (CCW), -1 horario (CW), 0 colineal. */
    public static int orientation(Vec2 a, Vec2 b, Vec2 c) {
        double v = orient(a, b, c);
        return v > EPS ? 1 : (v < -EPS ? -1 : 0);
    }

    // TEMA 2.6 Punto y línea
    /** Distancia con signo de p a la recta a->b: positiva si p está a la izquierda, negativa a la derecha. */
    public static double signedDistanceToLine(Vec2 p, Vec2 a, Vec2 b) {
        Vec2 ab = b.sub(a);
        return ab.cross(p.sub(a)) / ab.length();
    }

    /** Pie de la perpendicular de p sobre la recta a->b (se calcula con producto punto). */
    public static Vec2 projectOnLine(Vec2 p, Vec2 a, Vec2 b) {
        Vec2 ab = b.sub(a);
        double t = p.sub(a).dot(ab) / ab.dot(ab);
        return a.add(ab.mul(t));
    }

    /** Distancia de p al SEGMENTO a-b (t se limita a [0,1] para no pasarse de los extremos). */
    public static double distanceToSegment(Vec2 p, Vec2 a, Vec2 b) {
        Vec2 ab = b.sub(a);
        double t = Math.max(0, Math.min(1, p.sub(a).dot(ab) / ab.dot(ab)));
        return p.sub(a.add(ab.mul(t))).length();
    }

    // TEMA 2.5 Puntos y polígonos
    /** Punto dentro de un triángulo CCW: debe estar a la izquierda (o sobre) de sus 3 aristas. */
    public static boolean pointInTriangle(Vec2 p, Vec2 a, Vec2 b, Vec2 c) {
        return orient(a, b, p) >= -EPS && orient(b, c, p) >= -EPS && orient(c, a, p) >= -EPS;
    }

    /**
     * Punto dentro de un polígono cualquiera (convexo o cóncavo) con el NÚMERO:
     * se traza un rayo horizontal hacia +x desde p y se cuenta cuántas veces el contorno lo cruza;
     * la orientación (2.3) decide si cada cruce suma o resta. Si el total es distinto de 0, está dentro.
     */
    public static boolean pointInPolygon(Vec2 p, List<Vec2> poly) {
        int wn = 0, n = poly.size();
        for (int i = 0; i < n; i++) {
            Vec2 a = poly.get(i), b = poly.get((i + 1) % n);
            if (a.y <= p.y) {
                if (b.y > p.y && orient(a, b, p) > 0) wn++;
            } else {
                if (b.y <= p.y && orient(a, b, p) < 0) wn--;
            }
        }
        return wn != 0;
    }
}
