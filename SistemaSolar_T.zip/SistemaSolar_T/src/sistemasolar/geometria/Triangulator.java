package sistemasolar.geometria;

import java.util.ArrayList;
import java.util.List;

/**
 * UNIDAD 2 - TEMA 2.7 Triangulación de polígonos por RECORTE DE OREJAS (ear clipping).
 *
 * POR QUÉ: la pantalla solo sabe rellenar triángulos de forma sencilla, pero nuestros cuerpos son
 * polígonos (a veces CÓNCAVOS, como la estrella del Sol). Se parte el polígono en triángulos y se
 * rellena cada uno.
 * CÓMO: una "oreja" es un vértice convexo cuyo triángulo (anterior, actual, siguiente) no contiene
 * a ningún otro vértice. Se recorta la oreja y se repite hasta quedar un triángulo.
 * USA: orientación de 3 puntos (2.3) y punto en triángulo (2.5).
 */
public final class Triangulator {
    private Triangulator() {}

    /** Devuelve los triángulos como ternas de índices de los vértices originales. */
    public static List<int[]> earClipping(Polygon poly) {
        List<Vec2> v = poly.vertices();
        int n = v.size();
        List<Integer> idx = new ArrayList<>();
        if (poly.isCCW()) for (int i = 0; i < n; i++) idx.add(i);
        else for (int i = n - 1; i >= 0; i--) idx.add(i);       // se recorre al revés para trabajar en CCW

        List<int[]> tris = new ArrayList<>();
        while (idx.size() > 3) {
            boolean recortada = false;
            for (int i = 0; i < idx.size() && !recortada; i++) {
                int ip = idx.get((i + idx.size() - 1) % idx.size());
                int ic = idx.get(i);
                int in = idx.get((i + 1) % idx.size());
                Vec2 a = v.get(ip), b = v.get(ic), c = v.get(in);

                if (Geometry.orientation(a, b, c) <= 0) continue;   // vértice reflejo: no puede ser oreja

                boolean oreja = true;
                for (int j : idx) {
                    if (j == ip || j == ic || j == in) continue;
                    if (Geometry.pointInTriangle(v.get(j), a, b, c)) { oreja = false; break; }
                }
                if (oreja) {
                    tris.add(new int[]{ip, ic, in});
                    idx.remove(i);                                   // se recorta la oreja
                    recortada = true;
                }
            }
            if (!recortada) break;                                   // polígono degenerado: evita ciclo infinito
        }
        if (idx.size() == 3) tris.add(new int[]{idx.get(0), idx.get(1), idx.get(2)});
        return tris;
    }
}
