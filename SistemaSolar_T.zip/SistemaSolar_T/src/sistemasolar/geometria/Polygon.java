package sistemasolar.geometria;

import sistemasolar.transformaciones.Mat3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * UNIDAD 2 - TEMA 2.4 Polígonos.
 *
 * QUÉ ES: una lista ordenada de vértices. Cada cuerpo del sistema solar es un polígono definido en
 * coordenadas LOCALES (centrado en el origen, radio ~1); después las matrices de la Unidad 3 lo
 * mueven, lo giran y lo escalan hasta su lugar en pantalla.
 */
public final class Polygon {
    private final List<Vec2> v;

    public Polygon(List<Vec2> pts) {
        this.v = Collections.unmodifiableList(new ArrayList<>(pts));
    }

    public List<Vec2> vertices() { return v; }
    public int size() { return v.size(); }

    /** Área con signo (fórmula del zapatero): >0 si los vértices van en sentido antihorario. */
    public double signedArea() {
        double s = 0;
        for (int i = 0; i < v.size(); i++) s += v.get(i).cross(v.get((i + 1) % v.size()));
        return s / 2;
    }

    public double area()   { return Math.abs(signedArea()); }
    public boolean isCCW() { return signedArea() > 0; }

    /** Devuelve el polígono en sentido antihorario (lo que necesita la triangulación). */
    public Polygon asCCW() {
        if (isCCW()) return this;
        List<Vec2> r = new ArrayList<>(v);
        Collections.reverse(r);
        return new Polygon(r);
    }

    /** Convexo si todas las vueltas (orientación de 3 vértices seguidos, tema 2.3) giran al mismo lado. */
    public boolean isConvex() {
        int sign = 0, n = v.size();
        for (int i = 0; i < n; i++) {
            int o = Geometry.orientation(v.get(i), v.get((i + 1) % n), v.get((i + 2) % n));
            if (o == 0) continue;
            if (sign == 0) sign = o; else if (o != sign) return false;
        }
        return true;
    }

    /**
     * Aplica una transformación homogénea (Mat3) a TODOS los vértices.
     * Es el puente entre la Unidad 2 (polígonos) y la Unidad 3 (matrices).
     */
    public Polygon transform(Mat3 m) {
        List<Vec2> r = new ArrayList<>();
        for (Vec2 p : v) r.add(m.apply(p));
        return new Polygon(r);
    }

    /** Polígono regular de n lados y radio r (convexo). */
    public static Polygon regular(int n, double r) {
        List<Vec2> pts = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            pts.add(new Vec2(r * Math.cos(a), r * Math.sin(a)));
        }
        return new Polygon(pts);
    }

    /** Estrella de 'puntas' puntas (CÓNCAVA): alterna radio exterior e interior. */
    public static Polygon star(int puntas, double rExt, double rInt) {
        List<Vec2> pts = new ArrayList<>();
        for (int i = 0; i < 2 * puntas; i++) {
            double a = Math.PI * i / puntas + Math.PI / 2;
            double r = (i % 2 == 0) ? rExt : rInt;
            pts.add(new Vec2(r * Math.cos(a), r * Math.sin(a)));
        }
        return new Polygon(pts);
    }

    /** Polígono irregular (como un asteroide): radio al azar entre rMin y rMax. La semilla lo hace repetible. */
    public static Polygon irregular(int n, double rMin, double rMax, long semilla) {
        Random rnd = new Random(semilla);
        List<Vec2> pts = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            double a = 2 * Math.PI * i / n;
            double r = rMin + rnd.nextDouble() * (rMax - rMin);
            pts.add(new Vec2(r * Math.cos(a), r * Math.sin(a)));
        }
        return new Polygon(pts);
    }
}
