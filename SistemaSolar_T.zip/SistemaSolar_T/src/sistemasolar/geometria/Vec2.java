package sistemasolar.geometria;

/**
 * UNIDAD 2 - TEMA 2.1 Vectores y TEMA 2.2 Producto punto y cruz, en 2D.
 *
 * QUE ES: un par (x, y). Sirve para representar un PUNTO (una posición) o una DIRECCIÓN.
 * PARA QUÉ SE USA EN EL PROYECTO:
 *   - posición de cada cuerpo celeste y de los vértices de sus polígonos,
 *   - dirección de movimiento (la flecha verde de velocidad),
 *   - posición del mouse en pantalla.
 */
public final class Vec2 {
    public final double x, y;

    public Vec2(double x, double y) { this.x = x; this.y = y; }

    // 2.1 Operaciones básicas
    /** Suma: desplaza un punto con un vector (posición + desplazamiento). */
    public Vec2 add(Vec2 o)   { return new Vec2(x + o.x, y + o.y); }

    /** Resta: el vector que va de o hacia este punto (así se calcula una dirección). */
    public Vec2 sub(Vec2 o)   { return new Vec2(x - o.x, y - o.y); }

    /** Multiplicar por un número: cambia la longitud sin cambiar la dirección. */
    public Vec2 mul(double k) { return new Vec2(x * k, y * k); }

    /** Longitud (módulo) del vector: teorema de Pitágoras. */
    public double length()    { return Math.hypot(x, y); }

    /** Vector unitario (longitud 1): conserva solo la dirección. */
    public Vec2 normalized()  { double l = length(); return l == 0 ? this : mul(1.0 / l); }

    //  2.2 Producto punto y cruz
    /** Producto punto: a·b = ax*bx + ay*by = |a||b|cos(ángulo). Mide "cuánto apuntan al mismo lado". */
    public double dot(Vec2 o) { return x * o.x + y * o.y; }

    /** Producto cruz 2D (componente z): a×b = ax*by - ay*bx = |a||b|sen(ángulo).
     *  Su SIGNO indica si b está a la izquierda (+) o a la derecha (-) de a. */
    public double cross(Vec2 o) { return x * o.y - y * o.x; }

    /** Perpendicular a 90° antihorarios: (x, y) -> (-y, x). Se usa para dibujar las puntas de la flecha. */
    public Vec2 perp() { return new Vec2(-y, x); }

    @Override public String toString() { return String.format("(%.2f, %.2f)", x, y); }
}
