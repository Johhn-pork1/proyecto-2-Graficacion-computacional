# Sistema solar - Tarea de la Unidad 3 (Graficación Computacional)

Este proyecto es la **base de tu proyecto final**. Las Unidades 1 y 2 ya vienen resueltas.
Tu tarea es completar la **Unidad 3** (transformaciones geométricas). Lo que programes aquí se sigue usando
en las Unidades 4 y 5, así que no es un ejercicio aparte: es parte del proyecto.

**Entrega:** miércoles 11 de noviembre. **Equipos de 3.**

---

## 1. Abrir el proyecto en NetBeans

1. Descomprime `SistemaSolar_Tarea.zip`.
2. En NetBeans: **File > Open Project...** y elige la carpeta `SistemaSolar_Tarea` (tiene un icono de taza de café).
3. Si NetBeans pregunta por la plataforma Java, elige el JDK que tengas instalado (Java 8 o superior).
4. Para ver el programa: botón verde **Run Project** (F6). Se abre la ventana del sistema solar.

### Si NetBeans no reconoce el proyecto: créalo a mano, paso a paso

1. **File > New Project > Java with Ant > Java Application > Next.**
2. Nombre: `SistemaSolar_Tarea`. **Desmarca** "Create Main Class". **Finish.**
3. En la ventana *Projects*, clic derecho en **Source Packages > New > Java Package** y crea estos cuatro:
   `sistemasolar.geometria`, `sistemasolar.transformaciones`, `sistemasolar.rasterizacion`, `sistemasolar.escena`.
4. Copia los archivos `.java` del zip (carpeta `src/sistemasolar/...`) a la carpeta del paquete que les corresponde
   (en el explorador de archivos: `SistemaSolar_Tarea/src/sistemasolar/<paquete>/`). Vuelve a NetBeans y verás los archivos.
5. Clic derecho en el proyecto > **Properties > Sources > Encoding: UTF-8** (para que se vean los acentos).
6. **Properties > Run > Main Class:** `sistemasolar.escena.SolarSystem`.
7. **Run Project.**

---

## 2. Qué viene resuelto y qué te toca

| Ya resuelto | Tu tarea |
|---|---|
| `geometria/`: `Vec2`, `Vec3`, `Polygon`, `Geometry`, `Triangulator` (Unidad 2) | `transformaciones/Mat3.java`: Tareas 2, 3 y 4 |
| `rasterizacion/Canvas.java`: Bresenham, línea de doble paso y círculo (temas 4.1 a 4.3, para la Unidad 4) | `escena/Body.java`: Tareas 5a y 5b |
| `Mat3.apply` y `Mat3.desdeValores` (ejemplo resuelto del tema 3.3) | |
| `transformaciones/Mat4.java` y `Camera.java` (tema 3.6, modo 3D) | |
| El dibujo, el ciclo de animación y el teclado | `escena/SolarSystemPanel.java`: Tareas 5c y 5d |

**Cómo encontrar lo que falta:** busca los comentarios `TODO`. En NetBeans: **Window > IDE Tools > Tasks** (Ctrl+6)
los lista todos y puedes hacer doble clic para saltar a cada uno.

---

## 3. Orden recomendado (y qué verás en pantalla)

| Tarea | Tema | Dónde | Qué debes hacer |
|---|---|---|---|
| 1 | 3.3 Homogéneas | `Mat3.apply` | **Ya viene resuelta.** Léela: es el modelo de cómo se escribe una tarea |
| 2 | 3.1 y 3.2 | `Mat3.translation`, `rotation`, `scale`, `shearX` | Escribir las cuatro matrices (los dibujos están en los comentarios) |
| 3 | 3.5 Composición | `Mat3.times`, `rotationAbout` | Multiplicar matrices y rotar alrededor de un punto |
| 4 | 3.4 Inversas | `Mat3.inverse` | Deshacer una transformación |
| 5a | 3.5 | `Body.update` | Posición en la órbita componiendo T, R, T; la Luna debe seguir a la Tierra |
| 5b | 3.5 | `Body.update` | Matriz modelo T * R * S del polígono |
| 5c | 1.3 y 3.5 | `SolarSystemPanel.dibujar` | Viewport: de coordenadas del mundo a las de la pantalla |
| 5d | 3.4 y 2.5 | `SolarSystemPanel.cuerpoEn` | Convertir el clic del mouse a coordenadas locales con la inversa |

### Qué verás en pantalla al avanzar

El proyecto **arranca funcionando**: verás un sistema solar **quieto** (los cuerpos en su posición inicial, sin girar ni orbitar),
con el eje y al revés y sin zoom. Debajo de la tabla aparece un aviso amarillo que dice qué tarea falta. Cada tarea que
termines cambia lo que ves:

| Cuando termines... | Verás... |
|---|---|
| Nada todavía | Sistema solar quieto, aviso amarillo de pendientes |
| Tareas 2a, 2b y 3a, y luego 5a | Los cuerpos **orbitan** y la Luna sigue a la Tierra (el aviso de 5a desaparece) |
| Tareas 2c y 5b | Los cuerpos **giran** sobre sí mismos |
| Tarea 5c (escala con -zoom) | El eje y queda al derecho (órbitas antihorarias) y funcionan + y - (el aviso de 5c desaparece) |
| Tarea 5d (necesita la 4) | Clic sobre un cuerpo lo resalta y aparece en "Seleccionado" |

Las Tareas 2 a 4 son de la clase `Mat3`: su efecto se ve cuando las usas en la Tarea 5. Compara cada resultado con los
ejemplos que hicimos a mano en clase (el cuadrado A(1,1), B(3,1), C(3,3), D(1,3)) antes de seguir.

Si las órbitas van **al revés**, revisa el signo de la escala en y del viewport (Tarea 5c).
Si algo no cambia aunque ya escribiste tu código, revisa que la tarea anterior de la tabla esté terminada: las demás dependen de ella.

---

## 4. Cómo saber si va bien

Compara tu código con los ejemplos hechos a mano en clase: si una matriz no da el resultado del pizarrón, el error está
en tu código. Por ejemplo, con el cuadrado A(1,1), B(3,1), C(3,3), D(1,3), una rotación de 90° debe llevar A a (-1, 1).

**Qué entregar:** tu proyecto comprimido (zip) con el nombre del equipo, y una captura de pantalla del programa en
ejecución con un cuerpo seleccionado.

**Se revisa que:** los métodos de `Mat3` den el resultado correcto, la Tierra orbite, la Luna gire alrededor de la
Tierra, los cuerpos giren sobre sí mismos, el eje y y el zoom funcionen, y al hacer clic sobre un planeta se resalte
y aparezca su nombre en "Seleccionado".

---

## 5. Teclas del programa

| Tecla | Qué hace |
|---|---|
| ESPACIO | Pausa |
| T | Muestra la malla de triángulos (tema 2.7) |
| 3 | Cambia al modo 3D (tema 3.6, ya resuelto; compara el código con el modo 2D) |
| + / - | Acerca o aleja (es la escala del viewport) |
| R | Cambia entre dibujar las órbitas con los algoritmos de la Unidad 4 (`Canvas`) o con Java2D |
| Clic | Selecciona el cuerpo bajo el mouse |

---

## 6. Bono (opcional)

- **Inclinación del Sol (tema 3.1):** en `Body.update`, mete `Mat3.shearX(0.1 * Math.sin(2 * t))` entre la rotación y la escala
  solo para el Sol. Debe "parpadear".
- **Modo 3D (tema 3.6):** cambia el eje o el ángulo de `Mat4.rotationAxis` de la Luna y mira cómo cambia su órbita.
  Explica con tus palabras qué hace la fórmula de Rodrigues.

---

## 7. Qué sigue

En las Unidades 4 y 5 este mismo proyecto se extiende con dibujo de líneas y círculos pixel por pixel (Bresenham),
recorte (clipping), curvas de Bézier, ray tracing y animación. Guarda tu proyecto en un repositorio del equipo.
